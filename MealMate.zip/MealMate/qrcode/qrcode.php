<?php
session_start();
require_once '../connection.php';
require_once 'phpqrcode/qrlib.php';
$path = 'images/';
$qrcode = $path.time().".png";
$qrimage = time().".png";

if(isset($_REQUEST['sbt-btn']))	
{
	$sql = "select * from qrcode where username='$username'";
	// $querry = $_REQUEST[''];
	$qrtext = $_SESSION['username'];
// $qrtext = $_REQUEST[''];
// $query = mysqli_query($connection,"insert into qrcode set qrtext='$qrtext', qrimage='$qrimage'");
// $query = mysqli_query($connection,"select * from  into qrcode set qrtext='$qrtext', qrimage='$qrimage'");
	if($qrtext)
	{
		?>
		<script>
			alert("Data save successfully");
		</script>
		<?php
	}
}

QRcode :: png($qrtext, $qrcode, 'H', 4, 4);
echo "<img src='".$qrcode."'>";
?>