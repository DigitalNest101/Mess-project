<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">

<style>
        * {
            box-sizing: border-box;
            font-family: 'Open Sans', sans-serif;
            font-size: 18px;
            /*   border: 1px solid black; */
            margin: 0;
            padding: 0;
        }

        body {
            margin: 0;
            padding: 10% 0;
            position: relative;
            min-height: 100vh;
            background: #d15c21;
            display: flex;
            justify-content: center;
            animation: fadein 5s;
            animation-fill-mode: forwards;
        }

        .fadeIn {
            animation: fadein 5s;
            animation-fill-mode: forwards;
        }

        @keyframes fadein {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        label {
            display: block;
        }

        /* Model Container */

        .model {
            width: 900px;
            height: 700px;
            background: white;
            /*   font-size: 0; */
            color: white;
            position: relative;
            /*   animation: slideInFromLeft 1s cubic-bezier(0.68, -0.55, 0.265, 1.55); */
            animation-fill-mode: forwards;
        }

        .model:after {
            width: 30px;
            content: 'X';
            height: 30px;
            color: black;
            position: absolute;
            text-align: center;
            padding-top: 3px;
            top: 0;
            right: -30px;
            background-color: #bdc3c7;
        }

        @keyframes slideInFromLeft {
            0% {
                transform: translateY(-100%);
            }

            100% {
                transform: translateX(0);
            }
        }

        .room {
            width: 50%;
            height: 100%;
            background: url(https://images.unsplash.com/photo-1600335895229-6e75511892c8?auto=format&fit=crop&q=80&w=2787&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D) no-repeat center center;
            background-size: cover;
            display: inline-block;
            vertical-align: top;
            position: relative;
        }

        .text-cover {
            position: absolute;
            bottom: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.7);
            padding: 20px
        }

        .text-cover>* {
            margin: 10px 0;
        }

        .text-cover h1 {
            font-size: 1.8rem;
        }

        .text-cover .price {
            color: #e67e22;
        }

        .text-cover .price span {
            font-size: 1.4rem;
            font-weight: 700;
        }

        .payment {
            width: 40;
            height: 100%;
            color: #000000;
            display: inline-block;
        }

        .receipt-box {
            padding: 20px 20px;
            border-bottom: 1px solid #34495e;
        }

        .receipt-box h3,
        .payment-info h3 {
            margin-bottom: 2rem;
        }

        .payment-info {
            padding: 20px;
        }


        input[type=text] {
            width: 100%;
            padding: 8px 10px 10px;
            margin: 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn {
            padding: 15px 25px;
            border: none;
            color: white;
            width: 100%;
            display: block;
            background: #9b59b6;
            text-transform: uppercase;
        }

        .table {
            width: 100%;
            max-width: 100%;
            margin-bottom: 1rem;
            background-color: transparent;
        }

        .table td {
            font-size: 0.8rem;
            font-style: italic;
            padding: .25rem;
            vertical-align: top;

        }


        .table td:nth-child(2) {
            text-align: right;
        }
</style>
</head>

<body>
    <!-- <?php echo $_SESSION['username'] ?>
    <?php echo $_SESSION['id'] ?> -->



    <div class="model">
        <div class="room">
            <div class="text-cover">
                <h1>MealMate</h1>
            </div>
        </div>
        <div class="payment">
        <div class="receipt-box">
        <h3>Reciept Summary</h3>
        <table class="table">
          <tr>
            <td>DELUXE</td>
            <td>4,600</td>
          </tr>
          <tr>
            <td>Discount</td>
            <td>600</td>
          </tr>
          <tfoot>
            <tr>
              <td>Sum</td>
              <td>4,600</td>
            </tr>
          </tfoot>
        </table>
      </div>
            <div class="payment-info">
                <h3>Payment Info</h3>
                <form action="../qrcode/qrcode.php" method="post" >                                        
                    <br><br>
                    <!-- <a href="#"> -->
                    <!-- <input type="text" name="qrtext" id="qrtext" placeholder="Enter QR Text" required data-parsley-pattern="^[a-zA-Z]+$" data-parsley-trigger="keyup" class="form-control" /> -->


                    <input class="btn" type="submit" name="sbt-btn" value="Book Securly">Checkout</button>
                    <!-- <input type="submit" name="sbt-btn" value="QR Generate" class="btn btn-success" /> -->
                    </a>
                </form>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
    <script>
        var model = document.querySelector(".model");

        function fadeIn() {
            console.log('fadein')
            model.className += " fadeIn";
        }
    </script>
</body>

</html>